# Bouncing_Ball

Link:  https://gowthammca23.github.io/Bouncing_Ball/

BOUNCING BALL

## Description:

Elevate the animation by enabling user input for modifying the ball's movement, incorporating elements like keyboard and mouse controls, as well as introducing obstacles or targets to enhance interactivity.

## How to run the code:

Step1:Save the HTML file with a .html extension.

Step2:Click the "Go Live" button to open a new browser window displaying the Bouncing_Ball animation.

## Future improvement:

consider integrating user interaction like click-and-drag functionality, customizable ball properties, and physics-based interactions, such as ball collisions, for a more engaging and interactive animation.
